(* -------------------------------------------------------------------- *)
module J = Jasmin

let main () = J.Main_compiler.main ()

