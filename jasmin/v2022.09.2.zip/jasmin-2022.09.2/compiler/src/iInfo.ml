type t = Location.i_loc * Annotations.annotations
let dummy = Location.i_dummy, []
