type 'a syscall_t =
  | RandomBytes of 'a
