# Jasmin

## About

Jasmin denotes both a language and a compiler designed for
writing high-assurance and high-speed cryptography.

Information about the Jasmin compiler and the related tools
can be found in the [wiki](https://github.com/jasmin-lang/jasmin/wiki).

## License

Jasmin is free software. All files in this distribution are, unless specified
otherwise, licensed under the [MIT license](LICENSE).
